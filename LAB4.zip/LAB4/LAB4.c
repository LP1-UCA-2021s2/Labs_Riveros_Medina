
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <gtk/gtk.h>
#include <signal.h>
#include <unistd.h>
#include <gtk/gtkx.h>
#include <ctype.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>

	void on_b2_clicked (GtkButton *b);

	GtkWidget *b1;
	GtkWidget *b2;
	GtkWidget *b3;
	GtkWidget *label1;
    GtkWidget *window;
    GtkWidget *fixed;
    GtkBuilder *builder;

 int main (int argc, char *argv[])
 {

    gtk_init (&argc, &argv);

    builder = gtk_builder_new_from_file ("/home/lp1-2021/Lab4.glade");
    window = GTK_WIDGET(gtk_builder_get_object(builder,"window"));
    g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
    gtk_builder_connect_signals(builder, NULL);


    label1 = GTK_WIDGET(gtk_builder_get_object(builder,"label1"));
    fixed = GTK_WIDGET(gtk_builder_get_object(builder,"fixed"));
    b1 = GTK_WIDGET(gtk_builder_get_object(builder,"b1"));
    b2 = GTK_WIDGET(gtk_builder_get_object(builder,"b2"));
    b3 = GTK_WIDGET(gtk_builder_get_object(builder,"b3"));
    g_signal_connect (b2, "clicked", on_b2_clicked, NULL);

    gtk_widget_show_all (window);

    /* start the main loop, and let it rest there until the application is closed */
    gtk_main ();

    return EXIT_SUCCESS;
 }
 void on_b2_clicked (GtkButton *b){
	 gtk_label_set_text (GTK_LABEL(label1),(const gchar* )"holaaaaaaaa");
 }
